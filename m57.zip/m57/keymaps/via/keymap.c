#include QMK_KEYBOARD_H

#include "quantum.h"

#include "hal_pal.h"






const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
  [0] = LAYOUT(
   //,-------------------------------------------------------.     ,-------------------------------------------------------------.
     KC_ESC,   KC_1,    KC_2,    KC_3,   KC_4,   KC_5,                        KC_6,  KC_7,   KC_8,    KC_9,   KC_0,    KC_BSPC,
  //,-------------------------------------------------------.      ,-------------------------------------------------------------.
     KC_TAB,   KC_Q,    KC_W,    KC_E,   KC_R,   KC_T,  KC_UP,      KC_LEFT,  KC_Y,  KC_U,   KC_I,    KC_O,   KC_P,    KC_ENT,
  //|--------+--------+--------+--------+--------+--------+----|  |--------+--------+--------+--------+-+--------+-----+----------|
     KC_CAPS,  KC_A,    KC_S,    KC_D,    KC_F,  KC_G,  KC_DOWN,    KC_RIGHT, KC_H,  KC_J,   KC_K,    KC_L,   KC_SCLN, KC_QUOT,
  //|--------+--------+--------+--------+--------+--------+----'  `--------+--------+--------+-------+-----------+--------+--------|
     KC_LSFT,  KC_Z,    KC_X,    KC_C,    KC_V,  KC_B,  KC_MUTE,       RGB_MOD,  KC_N,  KC_M,   KC_COMM, KC_DOT, KC_SLSH, KC_DEL,
  //|--------+--------+-------+-------+---------+--------+-----.  ,--------+--------+--------+--------+--------+--------+--------|
                       KC_LCTL,MO(1),  KC_SPC,                        KC_ENT,  MO(2),  KC_RGUI
                 //`-----------------------------------------------'  `--------------------------'

  ),

  [1] = LAYOUT(
//--------------------------------Left Hand-----------------------------------| |--------------------------------Right Hand------------------------------------------------
   //,-------------------------------------------------------.     ,-------------------------------------------------------------.
     KC_ESC,   KC_F1,    KC_F2,    KC_F3,   KC_F4,   KC_F5,                        KC_F6,  KC_F7,   KC_F8,    KC_F9,   KC_F10,    KC_BSPC,
  //,-------------------------------------------------------.      ,-------------------------------------------------------------.
     KC_TAB,   KC_Q,    KC_W,    KC_E,   KC_R,   KC_T,  KC_UP,      KC_LEFT,  KC_Y,  KC_U,   KC_I,    KC_O,   KC_P,    KC_LBRC,
  //|--------+--------+--------+--------+--------+--------+----|  |--------+--------+--------+--------+-+--------+-----+----------|
     KC_CAPS,  KC_A,    KC_S,    KC_D,    KC_F,  KC_G,  KC_DOWN,    KC_RIGHT, KC_H,  KC_J,   KC_K,    KC_L,   KC_SCLN, KC_ENTER,
  //|--------+--------+--------+--------+--------+--------+----'  `--------+--------+--------+-------+-----------+--------+--------|
     KC_LSFT,  KC_Z,    KC_X,    KC_C,    KC_V,  KC_B,  KC_MUTE,       RGB_MOD,  KC_N,  KC_M,   KC_COMM, KC_DOT, KC_SLSH, KC_DEL,
  //|--------+--------+-------+-------+---------+--------+-----.  ,--------+--------+--------+--------+--------+--------+--------|
                         KC_LCTL,MO(1),  KC_SPC,                     KC_ENT,  MO(2), KC_RCTL
  ),

  [2] = LAYOUT(
   //,-------------------------------------------------------.     ,-------------------------------------------------------------.
     KC_ESC,   KC_1,    KC_2,    KC_3,   KC_4,   KC_5,                        KC_6,  KC_7,   KC_8,    KC_9,   KC_0,    KC_BSPC,
  //,-------------------------------------------------------.      ,-------------------------------------------------------------.
     KC_TAB,   KC_Q,    KC_W,    KC_E,   KC_R,   KC_T,  KC_UP,      KC_LEFT,  KC_Y,  KC_U,   KC_I,    KC_O,   KC_P,    KC_LBRC,
  //|--------+--------+--------+--------+--------+--------+----|  |--------+--------+--------+--------+-+--------+-----+----------|
     KC_CAPS,  KC_A,    KC_S,    KC_D,    KC_F,  KC_G,  KC_DOWN,    KC_RIGHT, KC_H,  KC_J,   KC_K,    KC_L,   KC_SCLN, KC_ENTER,
  //|--------+--------+--------+--------+--------+--------+----'  `--------+--------+--------+-------+-----------+--------+--------|
     KC_LSFT,  KC_Z,    KC_X,    KC_C,    KC_V,  KC_B,  KC_MUTE,       RGB_MOD,  KC_N,  KC_M,   KC_COMM, KC_DOT, KC_SLSH, KC_DEL,
  //|--------+--------+-------+-------+---------+--------+-----.  ,--------+--------+--------+--------+--------+--------+--------|
                          KC_LCTL,MO(1),  KC_SPC,                   KC_ENT,  MO(2), KC_RCTL
  ),

  [3] = LAYOUT(
    //,-------------------------------------------------------.     ,-------------------------------------------------------------.
     KC_ESC,   KC_1,    KC_2,    KC_3,   KC_4,   KC_5,                        KC_6,  KC_7,   KC_8,    KC_9,   KC_0,    KC_BSPC,
  //,-------------------------------------------------------.      ,-------------------------------------------------------------.
     KC_TAB,   KC_Q,    KC_W,    KC_E,   KC_R,   KC_T,  KC_UP,      KC_LEFT,  KC_Y,  KC_U,   KC_I,    KC_O,   KC_P,    KC_LBRC,
  //|--------+--------+--------+--------+--------+--------+----|  |--------+--------+--------+--------+-+--------+-----+----------|
     KC_CAPS,  KC_A,    KC_S,    KC_D,    KC_F,  KC_G,  KC_DOWN,    KC_RIGHT, KC_H,  KC_J,   KC_K,    KC_L,   KC_SCLN, KC_ENTER,
  //|--------+--------+--------+--------+--------+--------+----'  `--------+--------+--------+-------+-----------+--------+--------|
     KC_LSFT,  KC_Z,    KC_X,    KC_C,    KC_V,  KC_B,  KC_MUTE,       RGB_MOD,  KC_N,  KC_M,   KC_COMM, KC_DOT, KC_SLSH, KC_DEL,
  //|--------+--------+-------+-------+---------+--------+-----.  ,--------+--------+--------+--------+--------+--------+--------|
                      KC_LCTL,MO(1),  KC_SPC,                        KC_ENT,  MO(2),  KC_RCTL
                    //`--------------------------'  `--------------------------'
  )
};
#if defined(ENCODER_MAP_ENABLE)
const uint16_t PROGMEM encoder_map[][NUM_ENCODERS][2] = {
    [0] =   { ENCODER_CCW_CW(KC_RIGHT, KC_LEFT),          ENCODER_CCW_CW(KC_VOLD, KC_VOLU)  },
    [1] =   { ENCODER_CCW_CW(RGB_HUD, RGB_HUI),           ENCODER_CCW_CW(RGB_SAD, RGB_SAI)  },
    [2] =   { ENCODER_CCW_CW(RGB_VAD, RGB_VAI),           ENCODER_CCW_CW(RGB_SPD, RGB_SPI)  },
    [3] =   { ENCODER_CCW_CW(RGB_RMOD, RGB_MOD),          ENCODER_CCW_CW(KC_RIGHT, KC_LEFT) },
    //                  Encoder 1                                     Encoder 2
};
#endif


uint32_t counter = 1;
void matrix_scan_user(void) {
    counter++;

    if(counter % 5000 == 0){
        xprintf("current counter is %ld\n", counter);
    }

}
void qf_bootloader_jump(void) {

  uint32_t *p = (uint32_t *)0x2000FC00;
 //uint32_t *p = (uint32_t *)0x20000000;
    *p = 0xc220b134;

    NVIC_SystemReset();
}
extern void qf_bootloader_jump(void);
void bootloader_jump(void){
    qf_bootloader_jump();
}
